# Credit-Management-WebApp
Credit management web application created for the task given by Sparks Foundation Internship Program.


The SQL queries for the database creation is present in the file compnay.sql
