<html>
<head>
    <title>Home</title>
   <link rel="stylesheet" href="Assets/css/sty.css">
 </head>
<body >
  <div style="background-image: url('bg.png');"></div>
<div id="header">
       <br>
	   <img src="Assets/images/credit.jpg" width="200" height="200" style="float:right">
	   
       <h2 style=" font-family: Times New Roman, Times, serif; font-size: 65px  ; "> Credit Management System</h2>
	    
	   <br>
	   
    </div>
        <div id="section">
		
		<div class="topnav">
  <a class="active" href="#home">Home</a>
  <a href="getdetail.php" >View User</a>
  <a href="selectuser.php">Transfer Credit</a>
  
</div>

<img src="Assets/images/welcome.jpg" width="1350" height="400" style="horizontal-align:middle">

            <table>
                <tr></tr>
                <!--<tr>        
               
                <div class="css-button" >
                  <!--<p class="css-button-text">View Users</p>
                  <div class="css-button-inner">
                  <a href="getdetail.php" >
                  <div class="reset-skew">
                  <p class="css-button-inner-text">View Users</p>
                </div></a>
                </div>
                </div>

                </td>
                </tr>

                <tr>        
               <br> <br> <br> <br> <br>
               <div class="css-button" >
                <!-- <p class="css-button-text">Transfer Credit</p>
                 <div class="css-button-inner">
                 <a href="selectuser.php" >
                 <div class="reset-skew">
                 <p class="css-button-inner-text">Transfer Credit</p>
               </div></a>
               </div>
               </div>

               </td>
               </tr>-->

            </table>
    </div>

</body>
</html>